import 'dart:convert';
import 'dart:developer';

import 'package:http/http.dart' as http;

class ApiManager {
  postCall(
    String url,
    Map<String, dynamic> request,
  ) async {
    var uri = Uri.parse(url);
    http.Response response = await http.post(uri, body: request);

    log(response.body);
    return await json.decode(response.body);
  }

  getCall(
    String url,
    Map<String, dynamic> request,
  ) async {
    try {
      var uri2 = Uri.parse(url);
      uri2 = uri2.replace(queryParameters: request);
      http.Response response = await http.get(uri2);
      return await json.decode(response.body);
    } catch (e) {
      log('Error in getCall: $e');
    }
    return null;
  }
}
